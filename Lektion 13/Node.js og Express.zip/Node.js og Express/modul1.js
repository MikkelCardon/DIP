// modul1.js
module.exports = { x: 1 };