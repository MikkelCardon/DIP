// modul2.js
exports.p = { y: 2 };
exports.q = { z: 3 };