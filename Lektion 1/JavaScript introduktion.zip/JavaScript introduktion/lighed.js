// lighed.js
console.log(0 == false); // => true
console.log(0 === false); // => false