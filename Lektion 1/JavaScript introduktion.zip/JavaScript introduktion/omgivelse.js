// omgivelse.js
parseInt;
console;
Math;

console.log(parseInt('123') === +'123'); // => true
console.log(Math.trunc(Math.random() * 3)); // => 2