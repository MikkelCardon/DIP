// bigint.js
console.log(7n/2n);// => 3n
let n = 2n**53n;
console.log(n); // => 9007199254740992n
console.log(Number.MAX_SAFE_INTEGER); // => 9007199254740991
console.log(n**2n); // => 81129638414606681695789005144064n